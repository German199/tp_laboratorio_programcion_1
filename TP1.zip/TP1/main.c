#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "funciones.h"

int main(){

    float numerA = 0;
    float numerB = 0;
    float suma;
    float resta;
    float division;
    float multiplicacion;
    long double factorA;
    long double factorB;
    char seguir='y';

    printf("Ingrese el Primer Operando: \n");
                scanf("%f", &numerA);

    printf("Ingrese el Segundo Operando: \n");
                scanf("%f", &numerB);


    while (seguir == 'y'){
        switch(menu(&numerA, &numerB))
        {
            case 1:
                suma = sumar(numerA, numerB);
                printf("La suma de los operandos es: %.2f\n\n", suma);
                printf("Volver al menu: y\nSalir: \n\n");
                fflush(stdin);
                seguir = getch();
                if (seguir == 'y')
                    {
                        system("cls");
                        break;
                    }
            case 2:
                resta = restar(numerA, numerB);
                printf("La resta de los operandos es: %.2f\n\n", resta);
                printf("Volver al menu: y\nSalir: n\n\n");
                fflush(stdin);
                seguir = getch();
                if (seguir == 'y')
                    {
                        system("cls");
                        break;
                    }
            case 3:
                division = dividir(numerA, numerB);
                if (division == -1)
                    {
                        printf("No es posible dividir por 0.\n\n");
                    } else
                            {
                                printf("La division de los operandos es: %.2f\n\n", division);
                            }
                printf("Volver al menu: y\nSalir: n\n\n");
                fflush(stdin);
                seguir = getch();
                if (seguir == 'y')
                    {
                        system("cls");
                        break;
                    }
            case 4:
                multiplicacion = multiplicar(numerA, numerB);
                printf("La multiplicacion de los operandos es: %.2f\n\n", multiplicacion);
                printf("Volver al menu: y\nSalir: n\n\n");
                fflush(stdin);
                seguir = getch();
                if (seguir == 'y')
                    {
                        system("cls");
                        break;
                    }
            case 5:
                factorA = factorizacion(numerA);
                factorB = factorizacion(numerB);
                if (factorA == -1)
                    {
                        printf("No se puede realizar factorial de un numero negativo.\n");
                    } else
                    {
                        printf("Factorial del primer Operando es: %.2Lf\n\n", factorA); // [-std=c99] ACTIVADO
                    }
                if (factorB == -1)
                    {
                        printf("No se puede realizar factorial de un numero negativo.\n");
                    } else
                        {
                             printf("Factorial del segundo Operando es: %.2Lf\n\n", factorB);
                        }
                printf("Volver al menu: y\nSalir: \n\n");
                fflush(stdin);
                seguir = getch();
                if (seguir == 'y')
                    {
                        system("cls");
                        break;
                    } else {
                            seguir = 'n';
                            }
                break;
            case 6:
                suma = sumar(numerA, numerB);
                printf("La suma de los operandos es: %.2f\n", suma);
                resta = restar(numerA, numerB);
                printf("La resta de los operandos es: %.2f\n", resta);
                division = dividir(numerA, numerB);
                if (division == -1)
                    {
                        printf("No es posible dividir por 0.\n");
                    } else
                            {
                                printf("La division de los operandos es: %.2f\n", division);
                            }
                multiplicacion = multiplicar(numerA, numerB);
                printf("La multiplicacion de los operandos es: %.2f\n", multiplicacion);
                factorA = factorizacion(numerA);
                factorB = factorizacion(numerB);
                if (factorA == -1)
                    {
                        printf("No se puede realizar factorial de un numero negativo.\n");
                    } else
                    {
                        printf("Factorial del primer Operando es: %.2Lf\n\n", factorA);
                    }
                if (factorB == -1)
                    {
                        printf("No se puede realizar factorial de un numero negativo.\n");
                    } else
                        {
                             printf("Factorial del segundo Operando es: %.2Lf\n\n", factorB);
                        }
                printf("Volver al menu: y\nSalir: n\n\n");
                fflush(stdin);
                seguir = getch();
                if (seguir == 'y')
                    {
                        system("cls");
                        break;
                    } else {
                            seguir = 'n';
                            }
                break;
            case 7:
                seguir = 'n';
                break;
            default:
                system("cls");
                printf("\nLa opcion seleccionada es invalida, regresando al menu.. \n\n");
        }
        }

    return 0;
}

