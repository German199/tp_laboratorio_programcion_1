#include "funciones.h"
#include <stdio.h>

int menu(float* numerA , float* numerB)
{
        int opciones = 0;

        printf("Indique que desea hacer con los operandos: ");
        printf("\n1- Calcular la Suma\n");
        printf("2- Calcular la Resta\n");
        printf("3- Calcular la Division\n");
        printf("4- Calcular la Multiplicacion\n");
        printf("5- Calcular el Factorial\n");
        printf("6- Calcular todas las operaciones\n");
        printf("7- Salir\n");
        printf("Opcion elegida: ");
        scanf("%d", &opciones);

        return opciones;
}

float sumar(float numerA, float numerB){

    float resultado;
    resultado = numerA + numerB;
    return resultado;
}

float restar(float numerA, float numerB){

    float resultado;
    resultado = numerA-numerB;
    return resultado;
}
 float dividir(float numerA, float numerB){

    float resultado;
    resultado = numerA/numerB;
    return resultado;
}
float multiplicar(float numerA, float numerB){

    float resultado;
    resultado = numerA*numerB;
    return resultado;
}
float factorizacion(long double numerA)
{
    long double i, factorA = 1;
    if (numerA >= 0)
    {
        for (i = 1; i <= numerA; i++)
        factorA = factorA * i;
    } else
        {
            factorA = -1;
        }
return factorA;
}


