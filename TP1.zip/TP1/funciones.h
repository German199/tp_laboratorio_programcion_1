/** \brief menu de opciones de las funciones
 *
 * \param sleccion de funcion matematica a realizar
 * \param toma la opcion por switch
 * \return regresa la opcion seleccionada
 *
 */

int menu(float*, float*);

/** \brief funcion de suma
 *
 * \param obtiene los datos de los operandos
 * \param los suma
 * \return devuelve el resultado
 *
 */


float sumar(float, float);

/** \brief funcion de resta
 *
 * \param obtiene los datos de los operandos
 * \param los resta
 * \return devuelve el resultado
 *
 */

float restar(float, float);

/** \brief funcion dividir
 *
 * \param obtiene los datos de los operandos
 * \param los divide
 * \return devuelve el resultado
 *
 */


float dividir(float, float);

/** \brief funcion multiplicar
 *
 * \param obtiene los datos de los operandos
 * \param los multiplica
 * \return devuelve el resultado
 *
 */


float multiplicar(float, float);

/** \brief factoriza el operando deseado
 *
 * \param pregunto si el factorial es un numero natural, de caso contraio regresa un (-1)
 * \param con for() realizo las multiplicaciones hasta que el valor base (i) sea mayor que el numero ingresado
 * \return devuelve el resultado
 *
 */


float factorizacion(long double);
